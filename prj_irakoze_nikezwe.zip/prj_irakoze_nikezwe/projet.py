#auteurs: IRAKOZE Franco Davy et NIKEZWE EDDY FLORENT
#date:29/04/2016
#Projet AP1
from tkinter import*
from random import*
import matplotlib.pyplot as plt
import os



def N():
    """cette fonction récupère la valeur  du nombre de ligne colonne inscrite par le joueur.
    Cette valeur est donc global et elle peut être utilisé pour les autres fonctions""" 
    try:
        global nbcase
        nbcase=int(reponse.get())
    except ValueError:
        messagebox.showinfo("Erreur","Le nombre de colonnes et de lignes doit être un entier")
    nbcase=int(reponse.get())
    global x0
    global y0
    global case
    x0,y0=300//nbcase,300//nbcase
    case=600//nbcase
    
 
def fin ():
    """cette fonction arrête le jeu quand on appuie stop"""
    global Arret
    Arret=True
    enregistrer_grille()
    plt.xlabel('générations')
    plt.ylabel("taux d'occupations")
    plt.title("Evolution du taux d'occupation")
    plt.grid(True)
    plt.savefig("test.png")
    plt.plot(M)
    plt.show()
    
    
DD=dict()

    
def grille():
    """la fonction grille permet de tracer une grille  de nbcase ligne et nbcase colonne
    et initialise le contenu de la grille aléatoirement"""
    Can.delete(ALL)
    global E
    E=dict()
    I=dict()
    for i in range(nbcase+1):
        Can.create_line(x0+case*i, y0,x0+case*i,y0 + nbcase*case)
        Can.create_line(x0, y0+case*i,x0+nbcase*case ,y0+case*i)
    for r in range(nbcase):
        x = x0 + case * r + case // 2
        for c in range(nbcase):
            y = y0 + case * c + case // 2
            global s
            s=randint(0,1)
            I[(r, c)] = Can.create_text(x, y, text='')
            
            E[(r,c)]=s
            if E[(r,c)]==1:
                I[(r, c)]= Can.create_oval(x-(250//nbcase),y-(250//nbcase),x+(250//nbcase),y+(250//nbcase),fill='black')
                
        
        
def calcul_voisin():
    """cette fonction calcule le nombre de voisin vivant pour chaque cellule de la grille"""
    global L
    L=dict()
    for i in range(nbcase):
        for j in range(nbcase):
            n=0
            if E[((i-1)%nbcase,(j-1)%nbcase)]==1:
                n+=1
            if E[((i-1)%nbcase,(j+1)%nbcase)]==1:
                n+=1
            if E[(i,(j+1)%nbcase)]==1:
                n+=1
            if E[((i+1)%nbcase,j)]==1:
                n+=1
            if E[(i,(j-1)%nbcase)]==1:
                n+=1
            if E[((i+1)%nbcase,(j-1)%nbcase)]==1:
                n+=1
            if E[((i-1)%nbcase,j)]==1:
                n+=1
            if E[((i+1)%nbcase,(j+1)%nbcase)]==1:
                n+=1
            L[(i,j)]=n
M=[]
def jouer1():
    """cette fonction applique les règles du jeu de la vie sur chaque cellule,
    ensuite elle détermine  si elle sera vivante ou non à la prochaine génération"""     
    
    global M
    Can.delete(ALL)
    calcul_voisin()
    for i in range(nbcase+1):
        Can.create_line(x0+case*i, y0,x0+case*i,y0 + nbcase*case)
        Can.create_line(x0, y0+case*i,x0+nbcase*case ,y0+case*i)
    d=0
    for rr in range(nbcase):
        x = x0 + case * rr + case // 2
        for cc in range(nbcase):
            y = y0 + case * cc + case // 2
            
            if E[(rr,cc)]==1 and L[(rr,cc)]<2:
                DD[(rr, cc)]=Can.create_text(x,y,text='')
                E[(rr,cc)]=0
            if E[(rr,cc)]==1 and (L[(rr,cc)]==2 or L[(rr,cc)]==3):
                DD[(rr, cc)]= Can.create_oval(x-(250//nbcase),y-(250//nbcase),x+(250//nbcase),y+(250//nbcase),fill='black')
                E[(rr,cc)]=1
            if E[(rr,cc)]==1 and L[(rr,cc)] > 3:
                DD[(rr,cc)]=Can.create_text(x,y,text='')
                E[(rr,cc)]=0
            if E[(rr,cc)]==0 and L[(rr,cc)]==3:
               DD[(rr, cc)]= Can.create_oval(x-(250//nbcase),y-(250//nbcase),x+(250//nbcase),y+(250//nbcase),fill='black')
               E[(rr,cc)]=1
            if E[(rr,cc)]==0 and L[(rr,cc)]!=3:
                DD[(rr,cc)]=Can.create_text(x,y,text='')
                E[(rr,cc)]=0
            if E[(rr,cc)]==1:
                d=d+1
    M=M+[d]
    print (d,"/",nbcase**2)
    if Arret== False:
        fenetre.after(10,jouer1)#10 est le nombre de milli secondes entre deux changement de la grille
def V():
    """la fonction V nous permet de récupérer le nombre q entier qui sera pris comme le nombre de
    génération à ne pas dépasser pour le jeu de la vie"""
    try:
        global q
        q=int(reponse1.get())
    except ValueError:
        messagebox.showinfo("Erreur","Votre saisie doit être un entier")
    q=int(reponse1.get())

  
def jouer2():
    """cette fonction nous permet de jouer au jeu de la vie en lui imposant un
    nombre exact de générations mais, elle ne montre pas l'évolution du changement de la grille au cour du jeu"""
    j=0
    try:
        s=nbcase*2
    except NameError:
        messagebox.showinfo("Erreur","le nombre de lignes et colonnes n'est pas défini ou vous n'avez pas validé")
    try:
        Q=q+1
        
    except NameError:
        messagebox.showinfo("Erreur","le nombre de génération n'est pas défini ou vous n'avez pas confirmé")
    try:
        calcul_voisin()
    except TypeError:
        messagebox.showinfo("Erreur","Vous n'avez pas initialisé la grille") 
    
    while j<q:
        jouer1()
        j=j+1
    enregistrer_grille()
    plt.xlabel('générations')
    plt.ylabel("taux d'occupations")
    plt.title("Evolution du taux d'occupation")
    plt.grid(True)
    plt.savefig("test.png")
    plt.plot(M)
    plt.show()
    
    
def animation():
    """ cette fonction est une version du jeu de la vie où
    on voie l'animation dû au changement du taux d'occupation de la grille
    sans lui imposer un nombre de génération"""
    try:
        s=nbcase*2
    except NameError:
        messagebox.showinfo("Erreur","le nombre de lignes et colonnes n'est pas défini ou vous n'avez pas validé")
            
    try:
        calcul_voisin()
    except TypeError:
        messagebox.showinfo("Erreur","Vous n'avez pas initialisé la grille")      
    
    global Arret
    if Arret==True:
        Arret=False
        jouer1()
    
Arret= True    

def recupere_fichier():
    """cette fonction permet de récupérer la grille parmis celles préétablies""" 
    global R
    R= os.listdir('grilles')
    global fichier
    fichier=reponse2.get()
    if not fichier in R:
        messagebox.showinfo("Erreur"," Cette grille n'est pas préétablie")
    
def grille_ds_fichier():
    """cette fonction dessine la grille préétablie qu'on récupère avec la fonction recupere_fichier()"""
    global E
    E=dict()
    I=dict()
    canal=open('grilles/'+fichier,"r")
    
    global nbcase
    nbcase=int(canal.readline().rstrip('\n'))
    global x0
    global y0
    global case
    x0,y0=300//nbcase,300//nbcase
    case=600//nbcase
    for i in range(nbcase+1):
        Can.create_line(x0+case*i, y0,x0+case*i,y0 + nbcase*case)
        Can.create_line(x0, y0+case*i,x0+nbcase*case ,y0+case*i)
    case_vivantes=canal.readlines()
    for ligne in case_vivantes:
        rc=ligne.rstrip('\n').split(' ')
        r=int(rc[0])
        c=int(rc[1])
        x = x0 + case * r + case // 2
        y = y0 + case * c + case // 2
        E[(r,c)]=1
        I[(r, c)]= Can.create_oval(x-(250//nbcase),y-(250//nbcase),x+(250//nbcase),y+(250//nbcase),fill='black')
    canal.close()
    for r in range(nbcase):
        for c in range(nbcase):
            if not (r,c) in E: 
                E[(r,c)]=0
def init2():
    """
    cette fonction est actionné par un click sur un boutton et permet de faire en même temps
    l'appel de recupere_fichier() et de grille_ds_fichier()
    """
    Can.delete(ALL)
    recupere_fichier()    
    grille_ds_fichier()
 
  
def enregistrer_grille():
    """Cette fonction permet d'enregistrer une grille si le joueur le souhaite et
    le stoque dans Grilles le répertoire où se trouvent toutes les autres grilles préétablies
    """
    
    var=messagebox.askquestion("Fichier","voulez-vous sauvegarder la grille?")
    if var=='yes': 
        class MyDialog:
            def  __init__(self, fenetre):
                """
                Cette fonction fait apparaître une fenetre de dialogue si
                le joueur veut enregistrer une grille, c'est pour donner le nom de sauvegarde
                """
                top = self.top = Toplevel(fenetre)
                Label(top, text="Nom de sauvegarde").pack()
                self.e = Entry(top)
                self.e.pack(padx=30,pady=30)
                b = Button(top, text="OK", command=self.ok)
                b.pack(pady=5)
                
            def ok(self):
                """Cette fonction récupère le nom de sauvegarde entré par le joueur"""
                global f
                f=self.e.get()
                self.top.destroy()
                

       
        d = MyDialog(fenetre)

        fenetre.wait_window(d.top) 
        fichier=open('grilles/'+f,"a")
        fichier.write(str(nbcase)+'\n')
        for r in range(nbcase):
            for c in range(nbcase):
                if E[(r,c)]==1:
                    fichier.write(str(r)+' '+str(c)+'\n')
        fichier.close()
    var1=messagebox.askquestion("jeu de la vie","Voulez-vous continuer le jeu?")
    if var1=='yes':
            Can.delete(ALL)
            R= os.listdir('grilles')
            messagebox.showinfo("info","veuillez entrer de nouvelles valeurs et ")
    elif var1=="no":
        fenetre.quit()
        fenetre.destroy()

fenetre=Tk()
fenetre.title("JEU DE LA VIE")
frame1=Frame()
frame2=Frame()

texte1=Label(frame2,text="Pour jouer au jeu de la vie, trois options s'offrent à vous:").grid(row=0,column=0)
texte2=Label(frame2,text="1. entrer le nombre de lignes et colonnes, puis valider ensuite").grid(row=1,column=0)
texte3=Label(frame2,text=" entrer le nombre de générations voulus  et appuyer sur initialiser enfin cliquer sur jouer").grid(row=2,column=0)
texte4=Label(frame2,text="2. entrer le nombre de lignes et colonnes, et valider ").grid(row=3,column=0)
texte5=Label(frame2,text="puis appuyer sur initialiser enfin cliquer sur jouer avec animation(le jeu ne s'arrete que si on appuie sur stop)").grid(row=4,column=0)
texte6=Label(frame2,text="3. entrer une grille déja préetablie ensuite, soit entrer le nombre de générations").grid(row=5,column=0)
texte7=Label(frame2,text="voulus et cliquer sur jouer ou cliquer directement sur jouer avec animation").grid(row=6,column=0)
texte8=Label(frame2,text="les grilles préétablies sont:m1,p2,p4,s1,s3,s5,s7,v1,v3,p1,p3,s2,s4,s6,v2").grid(row=7,column=0)
frame2.pack(side=LEFT)
BouttonQuit=Button(frame1,text="stop", command=fin)
BouttonInitialisation=Button(frame1,text="initialiser", command=grille)
valeur=Button(frame1,text="valider",command=N)
jouer=Button(frame1,text="Jouer",command=jouer2)
T=Button(frame1,text="Confirmer",command=V)
B=Button(frame1,text="Jouer jeu avec animation",command=animation)
l=Button(frame1,text="Ok",command=init2)
Can=Canvas(fenetre,height=610,width=610,bg="white")

zone=Label(frame1,text= "Veuillez entrer le nombre de lignes et colonnes:").grid(row=0,column=0)
reponse=Entry(frame1)
reponse.grid(row=0,column=1)
valeur.grid(row=0,column=2)


zone1=Label(frame1,text="Le nombre de générations voulu puis cliquez sur jouer").grid(row=1,column=0)
reponse1=Entry(frame1)
reponse1.grid(row=1,column=1)
T.grid(row=1,column=2)


zone2=Label(frame1,text= "Ou veuillez entrer le nom de la grille que vous voulez récuperer:").grid(row=2,column=0)
reponse2=Entry(frame1)
reponse2.grid(row=2,column=1)
l.grid(row=2,column=2)



BouttonInitialisation.grid(row=3,column=0)
jouer.grid(row=3,column=1)
BouttonQuit.grid(row=3,column=2)
B.grid(row=3,column=3)
frame1.pack()

Can.pack()
fenetre.mainloop()
